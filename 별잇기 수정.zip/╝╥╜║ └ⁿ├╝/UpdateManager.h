#pragma once
class UpdateManager
{
public:
	void Updating();
};


#include "OnTriggerEvent.h"

//void testFN() {
//	OnTriggerEvent::getInstance()->hook();
//}
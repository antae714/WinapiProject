#pragma once
class Cls {};
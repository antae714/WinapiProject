#pragma once

class InputManager
{
public:
	void InputLogic();
};


#pragma once
class Command
{
public:
	virtual void play() = 0;
};


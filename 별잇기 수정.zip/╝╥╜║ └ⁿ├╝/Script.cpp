#include "Script.h"

void Script::Awake(GameObject* p_owner)
{
	owner = p_owner;
}

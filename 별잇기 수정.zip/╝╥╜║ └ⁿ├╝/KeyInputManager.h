#pragma once

class KeyInputManager
{
public:
	void InputLogic();
};

